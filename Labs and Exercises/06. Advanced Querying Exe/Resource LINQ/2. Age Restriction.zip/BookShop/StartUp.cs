﻿using System;
using System.Linq;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
           // DbInitializer.ResetDatabase(db);

            //2. Age Restriction
            var command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db, command));



        }

        //2. Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            /*Return in a single string all book titles, each on a new line, that have age restriction, equal to the given command.
             Order the titles alphabetically.
             Read input from the console in your main method, and call your method with the necessary arguments.
             Print the returned string to the console.
             Ignore casing of the input.*/

            var books = context
                .Books
                .Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true)) // true to ignore case
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b}");
            }

            return sb.ToString().Trim();
        }
    }
}
