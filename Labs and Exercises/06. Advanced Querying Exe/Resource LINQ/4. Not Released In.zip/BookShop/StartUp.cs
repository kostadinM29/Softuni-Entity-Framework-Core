﻿using System;
using System.Linq;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            var db = new BookShopContext();
            // DbInitializer.ResetDatabase(db);

            //2. Age Restriction
            //var command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            //3. Golden Books
            //Console.WriteLine(GetGoldenBooks(db));

            //4.Books by Price
            //Console.WriteLine(GetBooksByPrice(db));

            //5.Not Released In
            var command = int.Parse(Console.ReadLine());
            Console.WriteLine(GetBooksNotReleasedIn(db,command));

        }
        //5. Not Released In
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            /*Return in a single string all titles of books that are NOT released on a given year.
             Order them by book id ascending.*/

            var books = context
                .Books
                .Where(b=>b.ReleaseDate.Value.Year != year)
                .Select(b => new
                {
                    Id = b.BookId,
                    Title = b.Title
                })
                .OrderBy(b => b.Id)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }

            return sb.ToString().Trim();
        }
        //4. Books by Price
        public static string GetBooksByPrice(BookShopContext context)
        {
            /*Return in a single string all titles and prices of books with price higher than 40, each on a new row in the format given below.
             Order them by price descending.*/
            var books = context
                .Books
                .Where(b =>b.Price > 40)
                .Select(b => new
                {
                    Title = b.Title,
                    Price = b.Price
                })
                .OrderByDescending(b => b.Price)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title} - ${b.Price:F2}");
            }

            return sb.ToString().Trim();

        }
        //3. Golden Books
        public static string GetGoldenBooks(BookShopContext context)
        {
            /*Return in a single string titles of the golden edition books that have less than 5000 copies, each on a new line.
             Order them by book id ascending.*/

            var books = context
                .Books
                .Where(b => b.EditionType == Enum.Parse<EditionType>("Gold", true) && b.Copies < 5000)
                .Select(b => new
                {
                    Id = b.BookId,
                    Title = b.Title
                })
                .OrderBy(b => b.Id)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }

            return sb.ToString().Trim();

        }
        //2. Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            /*Return in a single string all book titles, each on a new line, that have age restriction, equal to the given command.
             Order the titles alphabetically.
             Read input from the console in your main method, and call your method with the necessary arguments.
             Print the returned string to the console.
             Ignore casing of the input.*/

            var books = context
                .Books
                .Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true)) // true to ignore case
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b}");
            }

            return sb.ToString().Trim();
        }
    }
}
