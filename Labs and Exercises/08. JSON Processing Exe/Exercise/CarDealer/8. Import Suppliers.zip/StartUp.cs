﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private const string DatasetsDirectoryPath = "../../../Datasets";

        private const string ResultsDirectoryPath = "../../../Datasets/Results";
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext(); 
            ResetDataBase(context);

            InitializeMapper();

            // 8. Import Suppliers
            string inputJson = File.ReadAllText($"{DatasetsDirectoryPath}/suppliers.json");
            Console.WriteLine(ImportSuppliers(context, inputJson));

        }
        // 8. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            //Import the suppliers from the provided file suppliers.json. 
            List<Supplier> suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

            context.Suppliers.AddRange(suppliers);

            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
        private static void ResetDataBase(CarDealerContext context)
        {
            context.Database.EnsureDeleted();
            Console.WriteLine("Database was deleted!");
            context.Database.EnsureCreated();
            Console.WriteLine("Database was created!");
        }
        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });
        }
    }

}