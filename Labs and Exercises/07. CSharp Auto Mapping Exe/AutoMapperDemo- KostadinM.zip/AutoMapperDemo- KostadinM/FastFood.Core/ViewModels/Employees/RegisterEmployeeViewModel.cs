﻿namespace FastFood.Core.ViewModels.Employees
{
    public class RegisterEmployeeViewModel
    {
        public int PositionId { get; set; }
    }
}
