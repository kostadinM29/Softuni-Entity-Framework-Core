﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Enums
{
    public enum Prediction
    {
        Win = 0,
        Draw = 1,
        Lose = 2
    }
}
