﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Enums
{
    public enum ResourceType
    {
        Video = 1,
        Presentation = 2,
        Document = 3,
        Other = 4
    }
}
