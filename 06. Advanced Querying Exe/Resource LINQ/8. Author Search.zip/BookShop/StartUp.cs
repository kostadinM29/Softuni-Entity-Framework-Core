﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            var db = new BookShopContext();
            // DbInitializer.ResetDatabase(db);

            //2. Age Restriction
            //var command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            //3. Golden Books
            //Console.WriteLine(GetGoldenBooks(db));

            //4.Books by Price
            //Console.WriteLine(GetBooksByPrice(db));

            //5.Not Released In
            //var command = int.Parse(Console.ReadLine());
            //Console.WriteLine(GetBooksNotReleasedIn(db,command));

            //6.Book Titles by Category
            //var command = Console.ReadLine();
            //Console.WriteLine(GetBooksByCategory(db,command));

            //7.Released Before Date
            //var command = Console.ReadLine();
            //Console.WriteLine(GetBooksReleasedBefore(db, command));

            //8. Author Search
            var command = Console.ReadLine();
            Console.WriteLine(GetAuthorNamesEndingIn(db, command));

        }
        //8. Author Search
        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            /*Return the full names of authors, whose first name ends with a given string.
            Return all names in a single string, each on a new row, ordered alphabetically.*/

            var authors = context
                .Authors
                .Where(a => a.FirstName.EndsWith(input))
                .Select(a => new
                {
                    FullName = a.FirstName + ' ' + a.LastName
                })
                .OrderBy(a => a.FullName)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var a in authors)
            {
                sb.AppendLine($"{a.FullName}");
            }

            return sb.ToString().TrimEnd();

        }
        //7. Released Before Date
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            /*Return the title, edition type and price of all books that are released before a given date.
            The date will be a string in format dd-MM-yyyy.
            Return all of the rows in a single string, ordered by release date descending. */

            var books = context
                .Books
                .Where(b => b.ReleaseDate < DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture))
                .OrderByDescending(b =>
                    b.ReleaseDate) // ordering here because after select we need to project the date again
                .Select(b => new
                {
                    Title = b.Title,
                    EditionType = b.EditionType.ToString(), // not sure if needed?
                    Price = b.Price
                })
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title} - {b.EditionType} - ${b.Price:F2}");
            }

            return sb.ToString().TrimEnd();

        }
        //6. Book Titles by Category
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            /*Return in a single string the titles of books by a given list of categories.
            The list of categories will be given in a single line separated with one or more spaces.
            Ignore casing.
            Order by title alphabetically.*/

            var categoriesList = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(c => c.ToLower()) // ignore casing
                .ToList();

            var books = context
                .Books
                .Where(b => b.BookCategories.Any(bc =>
                    categoriesList.Contains(bc.Category.Name.ToLower()))) // ignore casing
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b}");
            }

            return sb.ToString().TrimEnd();
        }
        //5. Not Released In
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            /*Return in a single string all titles of books that are NOT released on a given year.
             Order them by book id ascending.*/

            var books = context
                .Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .Select(b => new
                {
                    Id = b.BookId,
                    Title = b.Title
                })
                .OrderBy(b => b.Id)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }

            return sb.ToString().TrimEnd();
        }
        //4. Books by Price
        public static string GetBooksByPrice(BookShopContext context)
        {
            /*Return in a single string all titles and prices of books with price higher than 40, each on a new row in the format given below.
             Order them by price descending.*/
            var books = context
                .Books
                .Where(b => b.Price > 40)
                .Select(b => new
                {
                    Title = b.Title,
                    Price = b.Price
                })
                .OrderByDescending(b => b.Price)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title} - ${b.Price:F2}");
            }

            return sb.ToString().TrimEnd();

        }
        //3. Golden Books
        public static string GetGoldenBooks(BookShopContext context)
        {
            /*Return in a single string titles of the golden edition books that have less than 5000 copies, each on a new line.
             Order them by book id ascending.*/

            var books = context
                .Books
                .Where(b => b.EditionType == Enum.Parse<EditionType>("Gold", true) && b.Copies < 5000)
                .Select(b => new
                {
                    Id = b.BookId,
                    Title = b.Title
                })
                .OrderBy(b => b.Id)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }

            return sb.ToString().TrimEnd();

        }
        //2. Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            /*Return in a single string all book titles, each on a new line, that have age restriction, equal to the given command.
             Order the titles alphabetically.
             Read input from the console in your main method, and call your method with the necessary arguments.
             Print the returned string to the console.
             Ignore casing of the input.*/

            var books = context
                .Books
                .Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true)) // true to ignore case
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var b in books)
            {
                sb.AppendLine($"{b}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
