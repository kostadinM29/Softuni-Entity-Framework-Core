﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        private const string DatasetsDirectoryPath = "../../../Datasets";

        private const string ResultsDirectoryPath = "../../../Datasets/Results";

        public static void Main(string[] args)
        {

            var context = new ProductShopContext();
            ResetDataBase(context); // to avoid migrations

            // 01. Import Users
            string usersJson = File.ReadAllText($"{DatasetsDirectoryPath}/users.json");
            Console.WriteLine(ImportUsers(context, usersJson));

            // 02. Import Products
            string productsJson = File.ReadAllText($"{DatasetsDirectoryPath}/products.json");
            Console.WriteLine(ImportProducts(context, productsJson));

            // 03. Import Categories
            string categoriesJson = File.ReadAllText($"{DatasetsDirectoryPath}/categories.json");
            Console.WriteLine(ImportCategories(context, categoriesJson));

            // 04. Import Categories and Products
            string categoriesProductsJson = File.ReadAllText($"{DatasetsDirectoryPath}/categories-products.json");
            Console.WriteLine(ImportCategoryProducts(context, categoriesProductsJson));


        }
        // 04. Import Categories and Products
        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            //Import the users from the provided file categories-products.json. 
            var categoryProducts = JsonConvert.DeserializeObject<List<CategoryProduct>>(inputJson);

            context.CategoryProducts.AddRange(categoryProducts);

            context.SaveChanges();

            return $"Successfully imported {categoryProducts.Count}";
        }
        // 03. Import Categories
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            /*Import the users from the provided file categories.json.
             Some of the names will be null, so you don’t have to add them in the database.
             Just skip the record and continue.*/
            var categories = JsonConvert.DeserializeObject<List<Category>>(inputJson)
                .Where(c => c.Name != null)
                .ToList();

            context.AddRange(categories);

            context.SaveChanges();

            return $"Successfully imported {categories.Count}";
        }
        // 02. Import Products
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            //Import the users from the provided file products.json.
            var products = JsonConvert.DeserializeObject<List<Product>>(inputJson);

            context.AddRange(products);

            context.SaveChanges();

            return $"Successfully imported {products.Count}";
        }
        // 01. Import Users
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            //Import the users from the provided file users.json.
            var users = JsonConvert.DeserializeObject<List<User>>(inputJson);

            context.AddRange(users);

            context.SaveChanges();

            return $"Successfully imported {users.Count}";
        }
        private static void ResetDataBase(ProductShopContext context)
        {
            context.Database.EnsureDeleted();
            Console.WriteLine("Database was deleted!");
            context.Database.EnsureCreated();
            Console.WriteLine("Database was created!");
        }
    }
}