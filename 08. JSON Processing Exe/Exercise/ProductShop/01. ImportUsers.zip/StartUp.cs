﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        private const string DatasetsDirectoryPath = "../../../Datasets";

        private const string ResultsDirectoryPath = "../../../Datasets/Results";

        public static void Main(string[] args)
        {
            
            var context = new ProductShopContext();
            ResetDataBase(context); // to avoid migrations

            // 01. Import Users
            string inputJson = File.ReadAllText("../../../Datasets/users.json");

            var result = ImportUsers(context, inputJson);
            Console.WriteLine(result);

        }
        // 01. Import Users
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            List<User> users = JsonConvert.DeserializeObject<List<User>>(inputJson);

            context.AddRange(users);

            context.SaveChanges();

            return $"Successfully imported {users.Count}";
        }
        private static void ResetDataBase(ProductShopContext context)
        {
            context.Database.EnsureDeleted();
            Console.WriteLine("Database was deleted!");
            context.Database.EnsureCreated();
            Console.WriteLine("Database was created!");
        }
    }
}