﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private static void ImportPartCars(CarDealerContext context)
        {
            int carsCount = context
                .Cars
                .Count();
            int partsCount = context.Parts.Count();

            var partCars = new List<PartCar>();

            for (int i = 1; i <= carsCount; i++)
            {
                var partCar = new PartCar();

                partCar.CarId = i;

                partCar.PartId = new Random().Next(1, partsCount);

                partCars.Add(partCar);
            }

            context.PartCars.AddRange(partCars);

            context.SaveChanges();
            Console.WriteLine($"Successfully added {partCars.Count()} partCars!");
        }
        private const string DatasetsDirectoryPath = "../../../Datasets";

        private const string ResultsDirectoryPath = "../../../Datasets/Results";
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            ResetDataBase(context);

            InitializeMapper();

            ////--Import Parts
            //ImportPartCars(context);

            // 8. Import Suppliers
            string inputJson = File.ReadAllText($"{DatasetsDirectoryPath}/suppliers.json");
            Console.WriteLine(ImportSuppliers(context, inputJson));

            //// 9. Import Parts
            string inputJson2 = File.ReadAllText($"{DatasetsDirectoryPath}/parts.json");
            Console.WriteLine(ImportSuppliers(context, inputJson2));

            // 10. Import Cars
            string inputJson3 = File.ReadAllText($"{DatasetsDirectoryPath}/cars.json");
            Console.WriteLine(ImportCars(context, inputJson3));


        }
        // 10. Import Cars
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            //Import the cars from the provided file cars.json.
            List<ImportCarDto> carsDtos = JsonConvert.DeserializeObject<List<ImportCarDto>>(inputJson);

            List<Car> cars = new List<Car>();
            foreach (var carDto in carsDtos)
            {
                Car car = new Car()
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TravelledDistance = carDto.TravelledDistance
                };

                foreach (int partId in carDto.PartsId.Distinct())
                {
                    car.PartCars.Add(new PartCar()
                    {
                        PartId = partId
                    });
                }

                cars.Add(car);
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            //var cars = JsonConvert.DeserializeObject<List<Car>>(inputJson);

            //context.Cars.AddRange(cars);

            //context.SaveChanges();

            return $"Successfully imported {cars.Count}.";
        }
        // 9. Import Parts
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            /*Import the parts from the provided file parts.json.
             If the supplierId doesn’t exists, skip the record.*/
            var suppliers = context.Suppliers
                .Select(s => s.Id)
                .ToList();

            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson)
                .Where(p => suppliers.Contains(p.SupplierId))
                .ToList();

            context.Parts.AddRange(parts);

            context.SaveChanges();

            return $"Successfully imported {parts.Count}.";
        }
        // 8. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            //Import the suppliers from the provided file suppliers.json. 
            var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

            context.Suppliers.AddRange(suppliers);

            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
        private static void ResetDataBase(CarDealerContext context)
        {
            context.Database.EnsureDeleted();
            Console.WriteLine("Database was deleted!");
            context.Database.EnsureCreated();
            Console.WriteLine("Database was created!");
        }
        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });
        }
    }

}